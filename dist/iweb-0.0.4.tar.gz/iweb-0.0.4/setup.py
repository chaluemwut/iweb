from setuptools import setup

setup(
    name="iweb",
    version="0.0.4",
    description="iweb is a framework for developing Model View Controller (MVC).",
    author='Chaluemwut Noyunsan',
    packages=["iweb"],
    url='https://github.com/chaluemwut/iweb.git',
    download_url='https://github.com/chaluemwut/iweb.git'
)